python3 -m venv snsEnv
cd snsEnv/bin
./activate

pip install numpy
pip install matplotlib

pip freeze > requirements.txt
